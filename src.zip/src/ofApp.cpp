#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
    
    ofBackground(0);
    
    ///--------- Contour Finder ofxCv
    
    contourFinder.setMinAreaRadius(80);
    contourFinder.setMaxAreaRadius(1000);
    contourFinder.setSimplify(true);
    
    
    //--------- gui
    gui.setup();
    kinectGUI.setName("sound&mic");
    gui.add(pushScaler.set("pushScaler", 0.50, 0.05, 100.00));
    gui.add(fftMax.set("fftMax", 0.700, 0.200, 0.900));
    gui.add(fftMin.set("fftMin", 0.005, 0.001, 0.600));
    gui.add(timeScaleClick.set("timeScaleClick", 2.00, -2.0, 5.0));
    gui.add(rSpeed.setup("rSpeed", 2, 0, 100));
    gui.add(micMax.set("micMax", 10, 0.1, 25));
    gui.add(micMin.set("micMin", 0.001, 0.01, 5));
    gui.add(smooth.set("smooth", 4.0, 0.0, 32.0));
    
    kinectGUI.setup();
    kinectGUI.setName("kinect");
    kinectGUI.add(nearThresholds.set("nearThresholds", 80, 0, 150));
    kinectGUI.add(farThresholds.set("farThresholds", 160, 0, 255));
    kinectGUI.add(x.set("x", 20, 0, 400));
    kinectGUI.add(y.set("y", 0, 0, 400));
    kinectGUI.add(w.set("w", 1500, 0, 1500));
    kinectGUI.add(h.set("h", 700, 0, 800));
    
    contourFinderGUI.setup();
    contourFinderGUI.setName("contourFinder");
    contourFinderGUI.add(simplify.set("simplify", 30.0, 0.0, 40.0));
    contourFinderGUI.add(minAreaRadius.set("minAreaRadius", 50.0, 1.0, 100.0));
    contourFinderGUI.add(maxAreaRadius.set("maxAreaRadius", 500.0, 100.0, 1000.0));
    contourFinderGUI.add(tipSize.set("tipSize", 50, 10, 200));
    
    
    psGUI.setup();
    psGUI.setName("ps");
    psGUI.add(particleSpeed.set("particleSpeed", 1.0, 0.1, 10.0));
    psGUI.add(addParticles.set("addParticles", 20, 1, 50));

    
    ///------- microphone
    int bufferSize = 256;
    
    left.assign(bufferSize, 0.0);
    right.assign(bufferSize, 0.0);
    volHistory.assign(400, 0.0);
    
    bufferCounter	= 0;
    drawCounter		= 0;
    smoothedVol     = 0.0;
    scaledVol		= 0.0;
    
    
    ofSoundStreamSettings settings;
    
    // if you want to set the device id to be different than the default
    // auto devices = soundStream.getDeviceList();
    // settings.device = devices[4];
    
    // you can also get devices for an specific api
    // auto devices = soundStream.getDevicesByApi(ofSoundDevice::Api::PULSE);
    // settings.device = devices[0];
    
    // or get the default device for an specific api:
    // settings.api = ofSoundDevice::Api::PULSE;
    
    // or by name
    auto devices = soundStream.getMatchingDevices("default");
    if(!devices.empty()){
        settings.setInDevice(devices[0]);
    }
    
    settings.setInListener(this);
    settings.sampleRate = 44100;
    settings.numOutputChannels = 0;
    settings.numInputChannels = 2; /// here has to be "2"
    settings.bufferSize = bufferSize;
    
    soundStream.setup(settings);

    //soundStream.setup(this, 0, 1, 44100, bufferSize, 4);
    //(ofBaseApp * app, int outChannels, int inChannels, int sampleRate, int bufferSize, int nBuffers)
    
//    soundStream.printDeviceList();
//    
//    auto buffer = ofBufferFromFile("sound_channel.txt");
//    auto line = buffer.getLines().begin();
//    int deviceNumber = ofToInt(ofTrim(*line));
//    
//    std::cout << "Using device: " << deviceNumber << std::endl;
    
    
    
    ///---------- kinect v2
    kinectV2.open();
    panel.setup("", "settings.xml", 10, 100);
    panel.add(kinectV2.params);
    panel.loadFromFile("settings.xml");
    
    //ofSetLogLevel(OF_LOG_VERBOSE);

    ///---------- ofxCv with Kinect
    colorImg.allocate(kinectV2.width, kinectV2.height);
    grayImage.allocate(kinectV2.width, kinectV2.height);
    grayThreshNear.allocate(kinectV2.width, kinectV2.height);
    grayThreshFar.allocate(kinectV2.width, kinectV2.height);
    
    nearThreshold = 10;
    farThreshold = 178;
    bThreshWithOpenCV = true;
    
    ofSetFrameRate(30);
    
    //------- load song
    first.load("first.mp3");
    second.load("second.mp3");
    bgm.load("bgm.mp3");
    bgm.setVolume(0.5);
    
    ///-------- particle system
    for(unsigned int i = 0; i < totalParticles; i++){
        noiseOffset.push_back(ofVec2f(ofRandom(0,100000), ofRandom(0,100000)));
    }
    
    ///------- model
    model.loadModel("plane.obj", 20);
    goDie = false;
    randomOpacity = ofRandom(200, 255);
    opacityMin = 100;
    opacityMax = 255;

}

//--------------------------------------------------------------
void ofApp::update(){
    
    ofSoundUpdate();
    
    //lets scale the vol up to a 0-1 range
    scaledVol = ofMap(smoothedVol, 0.0, 0.17, 0.0, smooth, true);
    
    //lets record the volume into an array
    volHistory.push_back( scaledVol );
    
    //if we are bigger the the size we want to record - lets drop the oldest value
    if( volHistory.size() >= 400 ){
        volHistory.erase(volHistory.begin(), volHistory.begin()+1);
    }
    float mappedMic = ofMap(scaledVol, micMin, 2, 1, micMax, true);
    
    
//    cout << "smoothedVol: " << smoothedVol << endl;
//    cout << "scaledVol: " << scaledVol << endl;
//    cout << "mappedMic: " << mappedMic << endl;
    
    ///------ some setup
    
    totalParticles += addParticles;
    if (totalParticles > 3000){
        addParticles = 0;
    }
    
    contourFinder.setMinAreaRadius(minAreaRadius);
    contourFinder.setMaxAreaRadius(maxAreaRadius);
    
    ///------- Control of vertex opacity
    if(opacityDecrease){
        if(opacityMin > 0) {
            opacityMin -= 2;
        }
        if(opacityMax > 0) {
            opacityMax -= 2;
        }
        if(lineOpacity > 0){
            lineOpacity -= 1;
        }
    }
    
    ///------ model
    
    //! check we do load the model or not
    float time = ofGetElapsedTimef();
    
    if(model.getNumMeshes() > 0){
        
        //1. for model dots
        for(int i = 0; i < vertices.size(); i++ ){
            vertices[i].x += (pushScaler * mappedMic) * ofSignedNoise(time * 1 + offsetForVertex[i].x) ;
            vertices[i].y += (pushScaler * mappedMic) * ofSignedNoise(time * 1+ offsetForVertex[i].y) ;
            vertices[i].z += (pushScaler * mappedMic) * ofSignedNoise(time * 1 + offsetForVertex[i].z) ;
        }
        
        //2. for lines
        for(int i = 0; i < numVertices; i++ ){
            mesh.setVertex(i, vertices[i]);
        }
    }

    
    ///------- kinect
    kinectV2.update();
    
    if(kinectV2.isFrameNew()) {
        /// from ofxKinect2
        texDepth.loadData( kinectV2.getDepthPixels() );
        texRGB.loadData( kinectV2.getRgbPixels() );
        
        // load grayscale depth image from the kinect source
        ///?
        grayImage.setFromPixels(kinectV2.getDepthPixels());
        
        // we do two thresholds - one for the far plane and one for the near plane
        // we then do a cvAnd to get the pixels which are a union of the two thresholds
        if(false){
            //            bThreshWithOpenCV) {
            grayThreshNear = grayImage;
            grayThreshFar = grayImage;
            grayThreshNear.threshold(nearThresholds, true);
            grayThreshFar.threshold(farThresholds);
            cvAnd(grayThreshNear.getCvImage(), grayThreshFar.getCvImage(), grayImage.getCvImage(), NULL);
        } else {
            
            // or we do it ourselves - show people how they can work with the pixels
            ofPixels & pix = grayImage.getPixels();
            int numPixels = pix.size();
            
            rect.set(x,y,w,h);
            
            // Region of Interest
            for(std::size_t y= 0; y < grayImage.getHeight(); y++){
                for(std::size_t x = 0; x < grayImage.getWidth(); x++) {
                    if (!rect.inside(x, y))
                    {
                        pix.setColor(x, y, 255);
                    }
                }
            }
            
            for(int i = 0; i < numPixels; i++) {
                if(255 - pix[i] > nearThresholds && 255 - pix[i] < farThresholds) {
                    pix[i] = 255;
                } else {
                    pix[i] = 0;
                }
            }
        }
        
        grayImage.flagImageChanged();
        contourFinder.findContours(grayImage);
        contourFinderOpenCV.findContours(grayImage, 10, (kinectV2.width * kinectV2.height)/2, 20, false);
    }
    
    
    for (auto contourIndex = 0; contourIndex < contourFinder.size(); ++contourIndex)
    {
        ofPolyline contour = contourFinder.getPolylines()[contourIndex];
        ConvexHull convexHull(contour, hullMinumumDefectDepth);
        ofPolyline convexHullSmoothed = convexHull.convexHull();
        convexHullSmoothed.simplify(simplify);
        
        ///draw createPinkPlanes
        if (convexHullSmoothed.size() > 0)
        {
            while (pinkPlanes.size() <= maxParticles)
            {
                createPinkPlanes();
            }
        }

    }
    
//    if (!detectCountour && contourFinder.size() > 0)
//    {
//        first.play();
//        numGradualAdd = 100;
//        cout << "just play" << endl;
//    }
    /// bigBell will ring when the kinect first detect a contour
    /// and trigger to load a random 3d model
    if (!detectCountour && contourFinder.size() > 0)
    {
        numGradualAdd = 100;
        goDie = false;
        
        first.play();
        
        /// model starts to vanish after 7 seconds
        currentTime = ofGetElapsedTimef();
    }
    if(!reachTime && ofGetElapsedTimef() - currentTime  > timeInterval) {
        second.play();
        goDie = true;
        opacityDecrease = true;
        
    }
    if(ofGetElapsedTimef() - currentTime > timeInterval){
        reachTime = true;
    }else{
        reachTime = false;
    }
    
    if (contourFinder.size() > 0)
    {
        
        detectCountour = true;
        
        ofPolyline ourBiggestContour = contourFinder.getPolyline(0);
        std::vector<ofPolyline> allContours;
        for (std::size_t i = 0; i < contourFinder.size(); i++)
        {
            allContours.push_back(contourFinder.getPolyline(i));
        }
        
        
        if (!isfin)
        {
            for (auto& p: ps.particles)
            {
                for (std::size_t i = 0; i < contourFinder.size(); i++)
                {
                    ofPolyline thisContour = contourFinder.getPolyline(i);
                    if (!thisContour.inside(p->position.x, p->position.y))
                    {
                        p->ageSpeed = 10;
                        p->opcDecreaseSpeed = 3.0;
                        //p->age = 95;//std::numeric_limits<uint64_t>::max();
                    }
                    else
                    {
                        p->ageSpeed = 0;
                    }
                }
                
            }
        }
        else
        {
            for (auto& p: ps.particles)
            {
                for (std::size_t i = 0; i < contourFinder.size(); i++)
                {
                    ofPolyline thisContour = contourFinder.getPolyline(i);
                    if (!thisContour.inside(p->position.x, p->position.y))
                    {
                    p->ageSpeed = 0;
                    p->opcDecreaseSpeed = 2.75;
                    //p->age = 95;//std::numeric_limits<uint64_t>::max();
                    }
                }
            }
        }
        
        if (ps.particles.size() < totalParticles)
        {
            std::size_t numNeeded = totalParticles - ps.particles.size();
            
            if(numGradualAdd < numNeeded){
                numGradualAdd += addParticles;
            }
            
            // A --> whole image
            //std::vector<glm::vec2> newParticlesA = ofApp::getRandomPositionInsideOfPolyline(ourBiggestContour, numGradualAdd * 0.00);
            
            // B --> from convex hull
            //std::vector<glm::vec2> newParticlesB = ofApp::getRandomPositionInsideTips(ourBiggestContour, numGradualAdd * 0.80);
            
            // C --> from middle finger
            //std::vector<glm::vec2> newParticlesC = ofApp::getRandomPositionOneTips(ourBiggestContour, numGradualAdd * 0.80);
            std::vector<glm::vec2> newParticlesC = ofApp::getRandomPositionOneTipsMultipeContour(allContours, numGradualAdd);
            
            //std::vector<glm::vec2> newParticles = newParticlesA;
            
            //newParticles.insert(newParticles.end(), newParticlesB.begin(), newParticlesB.end());
            std::vector<glm::vec2> newParticles = newParticlesC;
            //newParticles.insert(newParticles.end(), newParticlesA.begin(), newParticlesA.end());
            
            
            
            
            for (auto position: newParticles)
            {
                glm::vec2 velocity;
                velocity.x = ofRandom(-particleSpeed, particleSpeed);
                velocity.y = ofRandom(-particleSpeed, particleSpeed);
                
                
                ps.particles.push_back(std::make_unique<Particle>(position, velocity));
            }
        }
        
        float time = ofGetElapsedTimef();
        
        for(int i = 0; i < ps.particles.size(); i++){
            ps.particles[i]->position.x += (ofSignedNoise(time * 5.0 + noiseOffset[i].x)) * mappedMic;
            ps.particles[i]->position.y += (ofSignedNoise(time * 5.0 + noiseOffset[i].y)) * mappedMic;
        }
        
        //        for (auto& p: ps.particles)
        //        {
        //            glm::vec2 position;
        //            position.x += (ofSignedNoise(time * 5.0 + noiseOffset.x)) * mappedMic;
        //
        //            vertices[i].x += (fftMapped * pushScaler) * ofSignedNoise(time * timeScaleClick + offsetForVertex[i].x) ;
        //            position.x += ofRandom(-micMax, micMax);
        //            position.y += ofRandom(-micMax, micMax);
        //            p->position += position;
        //        }
        
    }else{
        detectCountour = false;
    }
    
    // use gui to control particles' speed
    for (auto& p: ps.particles){
        p->displacementScale = particleSpeed;
    }
    ps.update();
    
    // Update the pinkPlanes
    for (std::size_t i = 0; i < pinkPlanes.size(); i++)
    {
        pinkPlanes[i]->update();
    }
    
    // Create an iterator for the particle vector.
    std::vector<std::shared_ptr<baseParticle> >::iterator iter = pinkPlanes.begin();
    
    while (iter != pinkPlanes.end())
    {
        if ((*iter)->getAge() > (*iter)->maximumAge)
        {
            iter = pinkPlanes.erase(iter);
        }
        else
        {
            ++iter;
        }
    }

}

//--------------------------------------------------------------
void ofApp::draw(){
    
    /// draw yellow circle on the center of contour
    /*
    for (auto contourIndex = 0; contourIndex < contourFinder.size(); ++contourIndex)
    {
        const ofPolyline contour = contourFinder.getPolylines()[contourIndex];
        ConvexHull convexHull(contour, hullMinumumDefectDepth);
        ofPolyline convexHullSmoothed = convexHull.convexHull();
        convexHullSmoothed.simplify(simplify);
     
        glm::vec3 contourCenters = ofApp::getContourCenter(contourIndex);
        ofSetColor(255, 255, 0, 200);
        ofDrawCircle(contourCenters, 30);
    }
    */
    
    ofSetColor(255, 255, 255);
    
    //cout << showFourCam << endl;
    
    if(showFourCam){
        ofPushMatrix();
        ofTranslate(ofGetWidth()/2 + 100, 0);
        texDepth.draw(10, 10, kinectWidth, kinectHeight);
        texRGB.draw(10 + 10 + kinectWidth, 10, kinectWidth, kinectHeight);
        grayImage.draw(10, 10 + 10 + kinectHeight, kinectWidth, kinectHeight);
        contourFinderOpenCV.draw(10 + 10 + kinectWidth,
                                 10 + 10 + kinectHeight, kinectWidth, kinectHeight);
        ofPopMatrix();
    }
    ///------- particle system on hand
    
    contourFinder.draw();
    ps.draw();
    for (std::size_t i = 0; i < pinkPlanes.size(); i++)
    {
        pinkPlanes[i]->draw();
    }
    
    ///------- gui
    float guiY = 600;
    gui.setPosition(0,guiY);
    gui.draw();
    kinectGUI.setPosition(gui.getWidth()+10, guiY);
    kinectGUI.draw();
    contourFinderGUI.setPosition(kinectGUI.getPosition().x + kinectGUI.getWidth() + 10, guiY);
    contourFinderGUI.draw();
    psGUI.setPosition(contourFinderGUI.getPosition().x + contourFinderGUI.getWidth() + 10, guiY);
    psGUI.draw();
    
    panel.draw();
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){
    switch (key) {
        case 'a':
            cout << " A Pressed" << endl;
            cout << "showFourCam" << endl;
            showFourCam = !showFourCam;
            break;
    }
}

std::vector<glm::vec2> ofApp::getRandomPositionOneTipsMultipeContour(const std::vector<ofPolyline>& polylines, std::size_t howManyParticles)
{
    std::vector<glm::vec2> results;
    glm::vec2 v;
    
    std::vector<ofPolyline> allContours;
    std::vector<ofPolyline> convexHullSmoothed;
    

        
    for (auto contourIndex = 0; contourIndex < contourFinder.size(); ++contourIndex)
    {
        
        ofPolyline contour = contourFinder.getPolylines()[contourIndex];
        ConvexHull convexHull(contour, hullMinumumDefectDepth);
        ofPolyline convexHullSmoothed = convexHull.convexHull();
        convexHullSmoothed.simplify(simplify);
        
        allContours.push_back(contour);
    }
    
    
    
    
    
    if (contourFinder.size() > 0)
    {
        for (std::size_t i = 0; i < howManyParticles; ++i)
        {
            glm::vec2 newParticle;
            bool found = false;
            do{
                ofRectangle smallBox;
                std::size_t randomContour = (int)ofRandom(0,contourFinder.size()); /// cout the random number
                smallBox.setFromCenter(allContours[randomContour][0].x, allContours[randomContour][0].y, tipSize, tipSize);
                newParticle.x = ofRandom(smallBox.getMinX(), smallBox.getMaxX());
                newParticle.y = ofRandom(smallBox.getMinY(), smallBox.getMaxY());
                
                for (std::size_t i = 0; i < contourFinder.size(); i ++)
                {
                    if(allContours[i].inside(newParticle.x, newParticle.y))
                    {
                        found = true;
                        break;
                    }
                }
            }while (!found);
            
            results.push_back(newParticle);
        }
    }
    return results;

    
    /*
        std::size_t contourIndex = 0;
        while (!allSimplifiedContours[contourIndex].inside(newParticle.x, newParticle.y))
        {
            contourIndex++;
            if (contourIndex >= contourFinder.size())
            {
                ofRectangle smallBox;
                smallBox.setFromCenter(allSimplifiedContours[contourIndex][0].x, allSimplifiedContours[contourIndex][0].y, tipSize, tipSize);
                newParticle.x = ofRandom(smallBox.getMinX(), smallBox.getMaxX());
                newParticle.y = ofRandom(smallBox.getMinY(), smallBox.getMaxY());
                contourIndex = 0;
            }
        }
        results.push_back(newParticle);
    }
     

    return results;
     
    */
    
    /*
    for (auto contourIndex = 0; contourIndex < contourFinder.size(); ++contourIndex)
    {
        
        if(allSimplifiedContours[contourIndex].size() > 0){
            
            
            ofRectangle smallBox;
            smallBox.setFromCenter(allSimplifiedContours[contourIndex][0].x, allSimplifiedContours[contourIndex][0].y, tipSize, tipSize);
            for (std::size_t i = 0; i < howManyParticles; ++i)
            {
                    glm::vec2 v;

                    while (!polylines[contourIndex].inside(v.x, v.y))
                    {
                        v.x = ofRandom(smallBox.getMinX(), smallBox.getMaxX());
                        v.y = ofRandom(smallBox.getMinY(), smallBox.getMaxY());
                    }
                    results.push_back(v);
            }
        }
        return results;
    }
    */
}

std::vector<glm::vec2> ofApp::getRandomPositionOneTips(const ofPolyline& polyline, std::size_t howMany)
{
    std::vector<glm::vec2> results;
    
    ofRectangle boundBox = polyline.getBoundingBox();
    for (auto contourIndex = 0; contourIndex < contourFinder.size(); ++contourIndex)
    {
        
        ofPolyline contour = contourFinder.getPolylines()[contourIndex];
        ConvexHull convexHull(contour, hullMinumumDefectDepth);
        ofPolyline convexHullSmoothed = convexHull.convexHull();
        convexHullSmoothed.simplify(simplify);
        
        if(convexHullSmoothed.size() > 0){
            ofRectangle smallBox;
            smallBox.setFromCenter(convexHullSmoothed[0].x, convexHullSmoothed[0].y, tipSize, tipSize);
            for (std::size_t i = 0; i < howMany; ++i)
            {
                glm::vec2 v;
                
                while (!polyline.inside(v.x, v.y))
                {
                    v.x = ofRandom(smallBox.getMinX(), smallBox.getMaxX());
                    v.y = ofRandom(smallBox.getMinY(), smallBox.getMaxY());
                }
                results.push_back(v);
            }
        }
        return results;
    }
}


glm::vec3 ofApp::getContourCenter(std::size_t i){
    
    ofPolyline _contour = contourFinder.getPolylines()[i];
    glm::vec3 center = _contour.getCentroid2D();
    
    return center;
}


void ofApp::audioIn(ofSoundBuffer & input){
    
    float curVol = 0.0;
    
    // samples are "interleaved"
    int numCounted = 0;
    
    //lets go through each sample and calculate the root mean square which is a rough way to calculate volume
    for (int i = 0; i < input.getNumFrames(); i++){
        left[i]		= input[i*2]*0.5;
        right[i]	= input[i*2+1]*0.5;
        
        curVol += left[i] * left[i];
        curVol += right[i] * right[i];
        numCounted+=2;
    }
    
    //this is how we get the mean of rms :)
    curVol /= (float)numCounted;
    
    // this is how we get the root of rms :)
    curVol = sqrt( curVol );
    
    smoothedVol *= 0.93;
    smoothedVol += 0.07 * curVol;
    
    bufferCounter++;
    
}

void ofApp::createPinkPlanes()
{
    // Create a half-sized box for calculations.
    ofPoint halfBoxSize = ofPoint(300,300,300);
    
    // Instantiate our base particle.
    std::shared_ptr<baseParticle> aParticle = std::make_shared<baseParticle>();
    
    // Change postion on convexHull
    for (auto contourIndex = 0; contourIndex < contourFinder.size(); ++contourIndex)
    {
        ofPolyline contour = contourFinder.getPolylines()[contourIndex];
        ConvexHull convexHull(contour, hullMinumumDefectDepth);
        ofPolyline convexHullSmoothed = convexHull.convexHull();
        convexHullSmoothed.simplify(simplify);
        
        for (auto point: convexHullSmoothed){
            aParticle->position = ofPoint(point.x, point.y, 0);
        }
    }
    
    // Set a random velocity.
    aParticle->velocity = ofPoint(ofRandom(-2, 2),
                                  ofRandom(5, 0),
                                  ofRandom(-3, 3));
    
    // Set a random drag.
    float drag = ofRandom(0.990, 0.999);
    
    // Our drag is the same in the x, y and z directions.
    aParticle->drag = ofPoint(drag, drag, drag);
    
    // Add the particle to our collection.
    pinkPlanes.push_back(aParticle);
}

void ofApp::modelSpeedSetup(){
    mesh = model.getMesh(0);
    vertices = mesh.getVertices();
    numVertices = mesh.getNumVertices();
    for (int i = 0; i < numVertices; ++i) {
        speed.push_back(glm::vec3(ofRandom(-1,1), ofRandom(-1,1), ofRandom(-1,1)));
        speed.back() *= 0.5;
    }
}

void ofApp::modelLoad(){
    
    //1. hana
    if(randomNum == 1){
        model.loadModel("hanaReduced.obj", 20);
    }else if (randomNum == 2){
        model.loadModel("apple.obj", 20);
    }else if (randomNum == 3){
        model.loadModel("deer.obj", 20);
    }else if (randomNum == 4){
        model.loadModel("sun-flower.obj", 20);
    }else if (randomNum == 5){
        model.loadModel("cat.obj", 20);
    }
    //! check load file or not
    if(model.getNumMeshes() > 0){
        model.setRotation(0, 90, 1, 0, 0);
        model.setRotation(0, 90, 0, 1, 0);
        model.setPosition(ofGetWidth()/2, ofGetHeight()/2 + 300, 0);
        numVertices = mesh.getNumVertices();
        modelSpeedSetup();
        for(int i = 0 ; i < vertices.size(); i++){
            offsetForVertex.push_back(glm::vec3(ofRandom(0,100000),ofRandom(0,100000),ofRandom(0,100000)));
        }
    }
}

