#pragma once

#include "ofMain.h"
#include "ofxGui.h"
#include "ofxAssimpModelLoader.h"
#include "ofxKinectV2.h"
#include "ofxCv.h"
#include "ofxOpenCv.h"
#include "CvUtils.h"

#include "Particle.h"
#include "ParticleSystem.h"
#include "baseParticle.h"
#include "sphereParticle.h"

class ofApp : public ofBaseApp{

	public:
		void setup();
		void update();
		void draw();

		void keyPressed(int key);
    
    /// debug
    bool showFourCam = true;
		
    ///------- particle system on hand
    std::vector<glm::vec2> getRandomPositionOneTipsMultipeContour(const std::vector<ofPolyline>& polylines, std::size_t howManyParticles);
    
    
    std::vector<glm::vec2> getRandomPositionOneTips(const ofPolyline& polyline, std::size_t howMany);
    
    std::size_t numGradualAdd = 10;
    std::size_t totalParticles = 100;
    
    ParticleSystem ps;
    std::vector<glm::vec2> noiseOffset;
    
    
    ///--------- Contour Finder
    ofxCv::ContourFinder contourFinder;
    float hullMinumumDefectDepth = 10;
    // a rect for region of interest
    ofRectangle rect;
    // project model on center of hand
    glm::vec3 getContourCenter(std::size_t i);
    //glm::vec3 contourCenters;
    bool detectCountour = false;
    /// contourFinder for kinect, in ofxOpenCV
    ofxCvContourFinder contourFinderOpenCV;
    
    ///---------- pink planes
    std::vector<std::shared_ptr<baseParticle>> pinkPlanes;
    int maxParticles = 300;
    void createPinkPlanes();
    
    ///------- model & vertex setup
    ofxAssimpModelLoader model;
    void modelSpeedSetup();
    void modelLoad();
    ofMesh mesh;
    ofMesh newMesh;
    vector<glm::vec3> vertices;
    vector<glm::vec3> speed;
    vector<glm::vec3> offsetForVertex;
    int numVertices;
    float lineOpacity = 100;

    
        //------- change controller
        bool goDie;
        float randomOpacity;
        bool opacityDecrease = false;
        float opacityMin, opacityMax;
    
    //------- 10 second timer
    float timeInterval = 7.0;
    float currentTime = 0.0;
    
    //--------- core
    ofEasyCam cam;
    int randomNum = 0;
    bool isPressed = false;
    ofSoundPlayer first, second, bgm;
    bool isfin = false;
    bool reachTime = false;
    
    ///---------- kinect v2
    ofxKinectV2 kinectV2;
    ofTexture texDepth;
    ofTexture texRGB;
    
    float kinectWidth = 512/2;
    float kinectHeight = 424/2;
    
    ///---------- kinect
    
    ofxCvColorImage colorImg;
    ofxCvGrayscaleImage grayImage; // grayscale depth image
    ofxCvGrayscaleImage grayThreshNear; // the near thresholded image
    ofxCvGrayscaleImage grayThreshFar; // the far thresholded image
    
    bool bThreshWithOpenCV;
    bool bDrawPointCloud = false;
    
    int nearThreshold;
    int farThreshold;
        
    //------- gui
    /// from ofxKinectV2
    ofxPanel panel;

    ofxPanel gui;
    ofParameter<float> pushScaler;
    ofParameter<float> fftMax;
    ofParameter<float> fftMin;
    ofParameter<float> timeScaleClick;
    ofParameter<float> smooth;
    ofParameter<float> micMax, micMin;
    
    ofxFloatSlider rSpeed;
    // kinect gui
    ofxPanel kinectGUI;
    ofParameter<float> nearThresholds, farThresholds;
    ofParameter<float> x, y, w, h;
    // controuFinder GUI
    ofxPanel contourFinderGUI;
    ofParameter<float> simplify;
    ofParameter<float> minAreaRadius, maxAreaRadius;
    ofParameter<float> tipSize;
    
    // particle system
    ofxPanel psGUI;
    ofParameter<float> particleSpeed;
    ofParameter<int> addParticles;
    
    ///------- microphone
	
    //old ver of audioIn
    //void audioIn(float * input, int bufferSize, int nChannels);
    void audioIn(ofSoundBuffer & input);
    
    vector <float> left;
    vector <float> right;
    vector <float> volHistory;
    
    int 	bufferCounter;
    int 	drawCounter;
    
    float smoothedVol;
    float scaledVol;
    
    ofSoundStream soundStream;
    
    


};
